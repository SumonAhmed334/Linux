
---

Disclaimers:

- **These are not official Zimbra/Synacor builds.**
- **Important:** These builds **might** also include [Pimbra patches](https://github.com/maldua-pimbra/maldua-pimbra) since `10.1.5`, `10.0.13`, `9.0.0.p44` versions in order to enhance security. You can check `+Info` link on a given download to see if Pimbra patches have been used as part of the config.build contents.
- **These builds are distributed in the hope that they will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.**

---

[![Maldua](https://maldua.github.io/zimbra-foss/downloads/images/maldua-logo.png)](https://maldua.github.io/zimbra-foss/) **MALDUA'S Zimbra FOSS Builds** brought to you by [![bTactic](https://maldua.github.io/zimbra-foss/downloads/images/btactic-logo.png) BTACTIC, open source & cloud solutions](https://www.btactic.com). [Zimbra Network Edition support from bTactic](https://www.btactic.com/zimbra/).

---
